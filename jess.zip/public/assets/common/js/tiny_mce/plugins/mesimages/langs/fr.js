tinyMCE.addI18n('fr.mesimages',{
	desc : 'Gestionnaire des images'
});
