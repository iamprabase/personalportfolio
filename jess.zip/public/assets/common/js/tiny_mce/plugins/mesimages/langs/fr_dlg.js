tinyMCE.addI18n('fr.mesimages_dlg',{
	title : 'Gestionnaire des images'
});
