tinyMCE.addI18n('fr.searchreplace_dlg',{
searchnext_desc:"Suivant",
notfound:"La recherche est termin\u00E9e.",
search_title:"Chercher",
replace_title:"Chercher/Remplacer",
allreplaced:"Toutes les occurences de la cha\u00EEne recherch\u00E9e ont \u00E9t\u00E9 remplac\u00E9es.",
findwhat:"Chercher",
replacewith:"Remplacer par",
direction:"Direction",
up:"Haut",
down:"Bas",
mcase:"Prendre la casse en compte",
findnext:"Suivant",
replace:"Remplacer",
replaceall:"Rempl. tous"
});