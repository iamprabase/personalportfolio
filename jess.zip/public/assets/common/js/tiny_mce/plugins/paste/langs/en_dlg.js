tinyMCE.addI18n('en.paste_dlg',{
text_title:"CTRL+V pour coller le texte dans la fen�tre",
text_linebreaks:"Conserver les retours chariots",
word_title:"CTRL+V pour coller le texte dans la fen�tre"
});