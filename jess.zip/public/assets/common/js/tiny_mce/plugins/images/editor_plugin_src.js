(function() {
	tinymce.create('tinymce.plugins.Images', {
		init : function(ed, url) {
			ed.addCommand('mceImages', function() {
				ed.windowManager.open({
					file : url + '/images.htm',
					width : 700,
					height : 550,
					inline : 1,
				}, {
					plugin_url : url
				});
			});
			
			ed.addButton('images', {
				title : 'Gestionnaire des images',
				cmd : 'mceImages',
				image : url + '/images/icon.gif'
			});
			
			ed.onNodeChange.add(function(ed, cm, n) {
				cm.setActive('images', n.nodeName == 'IMG');
			});
		},
		
		getInfo : function() {
			return {
				longname : 'Images',
				author : 'David Alexandre',
				authorurl : 'http://www.jadsystem.com',
				infourl : 'http://www.jadsystem.com',
				version : "3.0"
			};
		}
	});
	
	tinymce.PluginManager.add('images', tinymce.plugins.Images);
})();