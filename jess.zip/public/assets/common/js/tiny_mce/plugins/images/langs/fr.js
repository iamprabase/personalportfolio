tinyMCE.addI18n('fr.images',{
	desc : 'Upload and insert picture'
});