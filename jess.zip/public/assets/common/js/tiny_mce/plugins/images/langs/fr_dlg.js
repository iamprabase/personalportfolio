tinyMCE.addI18n('fr.images_dlg',{
title:"Gestionnaire des images",
del_sel_folder:"Supprimer la photo s�lectionn�e ?",
sel_files_for_del:"Selectionnez la photo � supprimer.",
files_to_del:"Valider pour supprimer la photo",
delete_str:"Supprimer",
create_new_fld:"Cr�er un nouveau dossier",
create_fld:"Cr�er dossier",
upload_files:"T�l�charger photo",
delete_file:"Supprimer la photo",

fancy_title:"Image en cours de t�l�chargement...",
fancy_back_alt:"Retournez � la liste des photos",
fancy_back:"Retour aux images",
fancy_browse:"Parcour",
fancy_begin_upload:"Lancer le t�l�chargement",
fancy_upload_files:"T�l�charger images",
fancy_clear:"Effacer la liste",
fancy_begin_upload_files:"Lancer le t�l�chargement",
fancy_general_status:"Statut g�n�ral",
fancy_file_status:"Statut du fichier"
});