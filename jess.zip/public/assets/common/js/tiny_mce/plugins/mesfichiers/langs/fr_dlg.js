tinyMCE.addI18n('fr.mesfichiers_dlg',{
	title : 'Gestionnaire des fichiers PDF'
	


});

