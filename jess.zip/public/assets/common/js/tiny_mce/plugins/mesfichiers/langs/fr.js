tinyMCE.addI18n('fr.mesfichiers',{
	desc : 'Gestionnaire des fichiers PDF'
});
