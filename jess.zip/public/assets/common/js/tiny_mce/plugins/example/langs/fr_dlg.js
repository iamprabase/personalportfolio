tinyMCE.addI18n('fr.example_dlg',{
	title : 'Gestionnaire de fichiers'
});
