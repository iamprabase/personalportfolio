tinyMCE.addI18n('fr.example',{
	desc : 'Gestionnaire de fichiers'
});
